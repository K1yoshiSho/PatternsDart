part of paper;

class Paper {
  int number;
  String firstLine;
  
  Paper(this.number, this.firstLine);
}